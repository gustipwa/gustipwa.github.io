<html>
<head>
<title>IDX Shop</title>
<link rel="stylesheet" type="text/css" href="button.css">
</head>

		<body background="42257.jpg">
<center>
	<br>
		<br>
		<img src="logo-last.png">
		<br>
		<hr>
		</center>
		<p align="center">
<strong><font face="verdana" size="2">
. <a title="Halaman Home" href="home.htm" ><font color="white"> Home </font></a> .
<a title="Halaman Utama" href="login.htm" ><font color="white"> Beranda </font></a> .
<a title="Halaman Tutorial" href="tutorial.htm" ><font color="white"> Tutorial </font></a> .
<a title="Halaman Daftar"href="index.htm" ><font color="white"> Daftar </font></a> . 
<a title="Halaman Tools"href="tool.htm" ><font color="white"> Tools Product </font></a> .
<a title="Halaman Tentang"href="about.htm"><font color="white"> About </font></a> . 
</font></strong></p><hr/>
<center>
	<br>
	<font color="white">========================[ Gambar Scampage ]========================</font><br>
	<br><font color="white" >Apple Email Valid (03.11.17)</font><br>
	<br><img width="550" height="250"  src="https://i.ytimg.com/vi/5QrQwL6REJo/maxresdefault.jpg"/>
		<br>
<br><font color="white">Harga     : Rp.500.000,00</font><br>
	<br><font color="white">========================[<button class="button button3" onclick="window.location.href='applev.htm'">-Back-</button>]========================</font>
	<br>
<font color="yellow">Copyright By @Gusti Pranata Ari Wibowo(</font><a href="https://www.instagram.com/gustipwa/"><font color="white">Contact Me</font></a><font color="yellow"> )</font>
</center>
</html>